<p class="has-line-data" data-line-start="0" data-line-end="3">This is a submition for Weekly Assignment 2.<br>
Available at: <a href="https://github.com/gamedev-at-ariel/gamedev-5782/blob/master/04-unity-triggers/homework.pdf">https://github.com/gamedev-at-ariel/gamedev-5782/blob/master/04-unity-triggers/homework.pdf</a><br>
Submission Patricipant: Noy Ohana</p>
<p class="has-line-data" data-line-start="4" data-line-end="5">This project is an implementation of 3HP for the spaceship and triple shoot option (Q1.3 and a creative Idea):</p>
<p class="has-line-data" data-line-start="6" data-line-end="8">In Q1.3 I needed to implement 3HP “bar” which means that each time the spaceship touches the player HP is decreased by 1, until the counter reaches 0 and the player dies.<br>
The script accepts a GameObject array which is filled by Hearth Sprite and each time a collision is happening a heart getting “Destroyed” in Unity.</p>
<p class="has-line-data" data-line-start="9" data-line-end="10">The Implementation:</p>
<ol>
<li class="has-line-data" data-line-start="10" data-line-end="11">Upon Touching the shaceship health reduced by 1.</li>
<li class="has-line-data" data-line-start="11" data-line-end="12">When 0 lives reached the Player is destroyed (Game Over)</li>
<li class="has-line-data" data-line-start="12" data-line-end="14">Add link to the Script in the repo!</li>
</ol>
<p class="has-line-data" data-line-start="14" data-line-end="15">To Use the triple shooting Use Crtl (the default timeout is set to 0.2f but changable anytime in the editor under PlayerSpaceship-&gt;Laser Shooter-&gt; Triple Shoot)</p>