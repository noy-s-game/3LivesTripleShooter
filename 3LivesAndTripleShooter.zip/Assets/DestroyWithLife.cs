using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/**
 * This component destroys its object whenever it triggers a 2D collider with the given tag.
 */
public class DestroyWithLife : MonoBehaviour
{
    [Tooltip("Every object tagged with this tag will trigger the destruction of this object")]
    [SerializeField] string triggeringTag; //string that holds the name of the enemy
    [SerializeField] GameObject[] hearts; // an array of hearts which stores the HP sprites
    [SerializeField] int life; //stores the emount of lives left
    bool Flife = true; //represents if the player is aliver or not

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.tag == triggeringTag && enabled && Flife == true)
        {
            Destroy(other.gameObject); //destroys the collided enemy

            //takes damage for out character (ship) and deducts one life
            this.life = this.life - 1; //first deduct the amount of lives
            Destroy(hearts[life].gameObject); //remove one heart from the array (causes the hearth in-game to disapper)
            if (life < 1) Flife = false; //if life is 0 than game over.
        }
        if (other.tag == triggeringTag && enabled && Flife == false)
        {
            Destroy(this.gameObject); //destroys the collided enemy
            Destroy(other.gameObject); //destroy the player since the player is dead
        }
    }

    
}
